﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Program
    {
        static int ColumnLetterToNumber(string columnTitle)
        {
            int result = 0;

            foreach (char c in columnTitle)
            {
                // Subtract 'A' and add 1 to get the value of the current character
                int value = c - 'A' + 1;

                // Multiply the result by 26 and add the value of the current character
                result = result * 26 + value;
            }

            return result;
        }

        static void Main(string[] agrs)
        {

            string columnTitle1 = "A";
            string columnTitle2 = "B";
            string columnTitle3 = "Z";
            string columnTitle4 = "AA";
            string columnTitle5 = "AB";
            string columnTitle6 = "DB";



            Console.WriteLine(columnTitle1 + "->" + ColumnLetterToNumber(columnTitle1));
            Console.WriteLine(columnTitle2 + "->" + ColumnLetterToNumber(columnTitle2));
            Console.WriteLine(columnTitle3 + "->" + ColumnLetterToNumber(columnTitle3));
            Console.WriteLine(columnTitle4 + "->" + ColumnLetterToNumber(columnTitle4));
            Console.WriteLine(columnTitle5 + "->" + ColumnLetterToNumber(columnTitle5));
            Console.WriteLine(columnTitle6 + "->" + ColumnLetterToNumber(columnTitle6));


            Console.ReadLine();
        }
    }
}
