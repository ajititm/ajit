﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {

            int columnNumber1 = 26;
            int columnNumber2 = 51;
            int columnNumber3 = 52;
            int columnNumber4 = 80;
            int columnNumber5 = 676;
            int columnNumber6 = 702;
            int columnNumber7 = 705;


            Console.WriteLine(columnNumber1 + "->" + NumberToExcelColumn(columnNumber1));
            Console.WriteLine(columnNumber2 + "->" + NumberToExcelColumn(columnNumber2));
            Console.WriteLine(columnNumber3 + "->" + NumberToExcelColumn(columnNumber3));
            Console.WriteLine(columnNumber4 + "->" + NumberToExcelColumn(columnNumber4));
            Console.WriteLine(columnNumber5 + "->" + NumberToExcelColumn(columnNumber5));
            Console.WriteLine(columnNumber6 + "->" + NumberToExcelColumn(columnNumber6));
            Console.WriteLine(columnNumber7 + "->" + NumberToExcelColumn(columnNumber7));

            Console.ReadLine();
        }
        static string NumberToExcelColumn(int columnNumber)
        {
            string columnName = "";
            while (columnNumber > 0)
            {
                int mode = (columnNumber - 1) % 26;
                char digit = (char)('A' + mode);
                columnName = digit + columnName;
                columnNumber = (columnNumber - 1) / 26;
            }
            return columnName;
        }
    }
}
